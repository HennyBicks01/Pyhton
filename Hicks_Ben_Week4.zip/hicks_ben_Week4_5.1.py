# 1. Unpacking a tuple into variables


# day, high_temperature = ('Monday', 87, 65)


# Error: Too many values to unpack. The tuple has three values but only two variables are provided on the left.


# 2. Accessing list by out-of-range index


# numbers = [1, 2, 3, 4, 5]


# numbers[10]


# Error: Index out of range. The list has only 5 elements, but you're trying to access the 11th.


# 3. Immutable string modification


# name = 'amanda'


# name[0] = 'A'


# Error: Strings are immutable in Python, so you can't modify them in place.


# 4. Accessing list with a non-integer index


# numbers = [1, 2, 3, 4, 5]


# numbers[3.4]


# Error: List indices must be integers, not floats.


# 5. Tuple modification


# student_tuple = ('Amanda', 'Blue', [98, 75, 87])


# student_tuple[0] = 'Ariana'


# Error: Tuples are immutable, so you can't change their elements once they've been set.


# 6. Invalid tuple concatenation


# ('Monday', 87, 65) + 'Tuesday'


# Error: Can only concatenate tuple to tuple, not a string.


# 7. Invalid use of += operator


# 'A' += ('B', 'C')


# Error: Strings are immutable, and you can't append a tuple to a string.


# 8. Delete a variable and then use it


# x = 7


# del x


# print(x)


# Error: After deleting `x`, it's no longer defined, so the `print` statement will raise a NameError.


# 9. Search for an element that doesn't exist in a list


# numbers = [1, 2, 3, 4, 5]


# numbers.index(10)


# Error: The `index` method will raise a ValueError because `10` isn't in the list.


# 10. Incorrect use of the `extend` method


# numbers = [1, 2, 3, 4, 5]


# numbers.extend(6, 7, 8)


# Error: The `extend` method expects an iterable, but individual numbers are given.


# 11. Removing a non-existent element from a list


# numbers = [1, 2, 3, 4, 5]


# numbers.remove(10)


# Error: The `remove` method will raise a ValueError because `10` isn't in the list.


# 12. Pop from an empty list


# values = []


# values.pop()


# Error: The `pop` method will raise an IndexError because the list is empty.
