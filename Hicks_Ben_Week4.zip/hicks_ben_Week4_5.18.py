numbers = list(range(1, 11))




# Using filter to get even numbers, then map to triple them, and finally sum to get the total

total = sum(map(lambda x: x*3, filter(lambda x: x % 2 == 0, numbers)))
print(total)




# Reimplemented using a list comprehension

total_comprehension = sum(x*3 for x in numbers if x % 2 == 0)
print(total_comprehension)