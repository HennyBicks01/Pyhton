alphabet = 'abcdefghijklmnopqrstuvwxyz'


# 1. The first half of the string using starting and ending indices.

print(alphabet[0:len(alphabet)//2])


# 2. The first half of the string using only the ending index.

print(alphabet[:len(alphabet)//2])


# 3. The second half of the string using starting and ending indices.

print(alphabet[len(alphabet)//2:])


# 4. The second half of the string using only the starting index.

print(alphabet[len(alphabet)//2:])


# 5. Every second letter in the string starting with 'a'.

print(alphabet[::2])


# 6. The entire string in reverse.

print(alphabet[::-1])


# 7. Every third letter of the string in reverse starting with 'z'.

print(alphabet[::-3])
