def unique_sorted(values):
    """Return a sorted list of unique values."""
    return sorted(set(values))


# Testing the function with a list of numbers

numbers = [3, 2, 1, 4, 4, 5, 6, 5, 7]
print(unique_sorted(numbers))  # Expected output: [1, 2, 3, 4, 5, 6, 7]


# Testing the function with a list of strings

strings = ["apple", "banana", "apple", "cherry", "banana", "date"]
print(unique_sorted(strings))  # Expected output: ['apple', 'banana', 'cherry', 'date']
