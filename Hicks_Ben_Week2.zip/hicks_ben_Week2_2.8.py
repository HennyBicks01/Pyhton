# print statement for the table
print("number\tsquare\tcube")

# loop from 0 to 5

for number in range(6):  
    square = number ** 2
    cube = number ** 3
    print(f"{number}\t{square}\t{cube}")

# or in one line

# print("number\tsquare\tcube\n" + '\n'.join(f"{number}\t{number**2}\t{number**3}" for number in range(6)))