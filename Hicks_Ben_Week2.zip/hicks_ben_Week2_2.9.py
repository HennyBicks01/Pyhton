# Characters

characters = ['B', 'C', 'D', 'b', 'c', 'd', '0', '1', '2', '$', '*', '+', ' ']

# for loop for ord

for char in characters:
    print(f"The integer equivalent of '{char}' is: {ord(char)}")