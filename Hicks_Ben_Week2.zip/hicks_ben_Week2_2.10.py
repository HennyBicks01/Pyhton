# Input three integers from the user

num1 = int(input("Enter the first integer: "))
num2 = int(input("Enter the second integer: "))
num3 = int(input("Enter the third integer: "))

# Calculate the sum, average, and product

total_sum = num1 + num2 + num3
average = total_sum / 3
product = num1 * num2 * num3

# Determine the smallest and largest numbers

smallest = min(num1, num2, num3)
largest = max(num1, num2, num3)

# Display the results

print(f"Sum: {total_sum}")
print(f"Average: {average}")
print(f"Product: {product}")
print(f"Smallest: {smallest}")
print(f"Largest: {largest}")

# or do it goofy like

# print((lambda a, b, c: (s:=a+b+c, s/3, a*b*c, min(a,b,c), max(a,b,c)))(*map(int, list(input("Enter a three-digit number: ")))))