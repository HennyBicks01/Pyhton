# Constants

p = 1000  # principal amount
r = 0.07  # annual rate of return as a decimal

# Calculate and print the amount for 10, 20, and 30 years

for n in [10, 20, 30]:
    a = p * (1 + r) ** n
    print(f"Amount after {n} years: ${a:.2f}")

# or oneline it like:

# print('\n'.join(f"Amount after {n} years: ${1000 * (1 + 0.07) ** n:.2f}" for n in [10, 20, 30]))