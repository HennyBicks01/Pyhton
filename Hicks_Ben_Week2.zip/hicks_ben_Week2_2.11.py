# Input a five-digit integer from the user

number = int(input("Enter a five-digit integer: "))

# Get and print the first digit

digit1 = number // 10000
print(digit1, end='   ')

# Update number by removing the first digit

number %= 10000

# Get and print the second digit

digit2 = number // 1000
print(digit2, end='   ')

# Update number by removing the second digit

number %= 1000

# Get and print the third digit

digit3 = number // 100
print(digit3, end='   ')

# Update number by removing the third digit

number %= 100

# Get and print the fourth digit

digit4 = number // 10
print(digit4, end='   ')

# Get and print the fifth digit (last digit)

digit5 = number % 10
print(digit5)

# could just do:

# print('   '.join(input("Enter a five-digit integer: ")))