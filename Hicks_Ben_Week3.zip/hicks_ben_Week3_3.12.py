# check if given number is palindrome

def is_palindrome(num):
    # Extract individual digits
    digit1 = num // 10000  # First digit
    digit2 = (num % 10000) // 1000  # Second digit
    # digit3 = (num % 1000) // 100  (Middle digit, not needed for palindrome check)
    digit4 = (num % 100) // 10  # Fourth digit
    digit5 = num % 10  # Fifth digit

    # Check if the number is a palindrome
    return digit1 == digit5 and digit2 == digit4

# main function executes palindrome check

def main():
    # Prompt user for input
    num = int(input("Enter a five-digit integer: "))

    # Check if the number is 5 digits long
    if num < 10000 or num > 99999:
        print("Please enter a valid five-digit number.")
        return

    # Check and print the result
    if is_palindrome(num):
        print(f"{num} is a palindrome.")
    else:
        print(f"{num} is not a palindrome.")

#entry point

if __name__ == '__main__':
    main()

# or

# print(f"{(n:=input('Enter a five-digit integer: '))} is {'a palindrome' if re.match(r'^(\d)(\d)\d\2\1$', n) else 'not a palindrome'}." if re.match(r'^\d{5}$', n) else "Please enter a valid five-digit number.")