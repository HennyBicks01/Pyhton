def factorial(n):
    """Calculate the factorial of n."""
    if n == 0:
        return 1
    else:
        return n * factorial(n - 1)


def main():
    n = None
    try:
        # Input a nonnegative integer from the user
        n = int(input("Enter a nonnegative integer: "))

        # Ensure the number is nonnegative
        if n < 0:
            print("Please enter a nonnegative integer.")
            return

        # Compute and display the factorial
        result = factorial(n)
        print(f"The factorial of {n} is {result}")

    except ValueError:
        print("Please enter a valid integer.")

    except RecursionError:
        print(f"The factorial of {n} is too large to compute using this method.")

if __name__ == "__main__":
    main()


# or in one line with


# print((lambda f: f(f))(lambda f: (lambda n: 1 if n == 0 else n * f(f)(n-1)))(int(input("Enter a nonnegative integer: "))))

"""Enter a nonnegative integer: 30
The factorial of 30 is 265252859812191058636308480000000
Enter a nonnegative integer: 100
The factorial of 100 is 93326215443944152681699238856266700490715968264381621468592963895217599993229915608941463976156518286253697920827223758251185210916864000000000000000000000000
Enter a nonnegative integer: 1000
The factorial of 1000 is too large to compute using this method."""


