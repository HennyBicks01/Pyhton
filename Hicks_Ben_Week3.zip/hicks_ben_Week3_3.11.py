# Initialize variables to keep track of total miles and total gallons

total_miles = 0.0
total_gallons = 0.0


# While loop to emulate the miles driven by the tank

while True:

    # Get the gallons used from the user
    gallons = float(input("Enter the gallons used (-1 to end): "))
    
    # Check if the sentinel value is entered
    if gallons == -1:
        break
    
    # Get the miles driven from the user
    miles = float(input("Enter the miles driven: "))
    
    # Add to the totals
    total_gallons += gallons
    total_miles += miles
    
    # Calculate and display miles per gallon for the current tankful
    mpg = miles / gallons
    print(f"The miles/gallon for this tank was {mpg:.6f}")


# Calculate and display the overall average miles per gallon

if total_gallons != 0:  # To prevent division by zero
    overall_mpg = total_miles / total_gallons
    print(f"The overall average miles/gallon was {overall_mpg:.6f}")
else:
    print("No gallons were entered.")
