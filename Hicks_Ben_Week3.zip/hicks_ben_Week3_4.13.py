def product(*args):
    """
    Calculate the product of a series of integers.
    """
    result = 1
    for arg in args:
        result *= arg
    return result

if __name__ == "__main__":
    print(product(5, 4, 3, 2, 1))  # 120
    print(product(10, 20))         # 200
    print(product(7, 6, 5, 4))     # 840
    print(product(11))             # 11
    print(product())               # 1
